import { useState } from "react";
import { AuthContext } from "./AuthContext";
import type { User } from "../types/user";

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  function login() {
    setUser(user);
  }
  function logout() {
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, isLoggedIn: !!user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthProvider;
