
import { navigationItems } from "../data/navigation";
import { useDrawer } from "../hooks/useDrawer";

export default function Drawer() {
  const { isOpen, closeDrawer } = useDrawer();

  return (
    <>
      {isOpen && (
        <div
          className="overlay"
          onClick={closeDrawer}
        />
      )}

      <aside
        className={`drawer ${
          isOpen ? "open" : ""
        }`}
      >
        <div className="drawer-header">
          <h2>Sourdough Bakery & Cafe</h2>

          <button onClick={closeDrawer}>
            ✕
          </button>
        </div>

        <nav>
          {navigationItems.map((item) => (
            <button
              key={item.id}
              className="drawer-item"
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="drawer-footer">
          <button>Log in</button>
          <button>Sign up</button>
        </div>
      </aside>
    </>
  );
}