import { IconMugFilled } from "@tabler/icons-react";
import { useDrawer } from "../hooks/useDrawer";

function Header() {
    const { openDrawer } = useDrawer();

    return (   
        <header className="header">
            <button onClick={openDrawer}>☰</button>
            <h1>Cafe Shop</h1>
            <IconMugFilled />
        </header>
    );
}

export default Header;