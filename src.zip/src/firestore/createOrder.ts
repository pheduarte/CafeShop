import { db } from "../firestore/firebase-config";
import { collection, addDoc } from "firebase/firestore";
import type { Beverage } from "../types/beverages";
import type { User } from "../types/user";

export async function addNewOrder(
  user: User,
  items: Beverage[],
  total: number,
  paid: boolean,
) {
  //temporarily hardcoded
  await addDoc(collection(db, "orders"), {
    orderNumber: 1,
    user: user.name,
    time: Date,
    items: items,
    total: total,
    type: "pickup",
    tableNumber: 1,
    status: "waiting",
    paid: paid,
    specialInstructions: "",
  });
}
